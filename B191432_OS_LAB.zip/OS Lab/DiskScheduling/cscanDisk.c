//CSCAN -- Circular SCAN -- Disk Scheduling Algorithm

/*
Input/Output:
1)
Enter number of requests: 7                                                                                             
Enter queue of requests: 78 63 14 53 46 97 182                                                                          
Enter head position: 50                                                                                                 
Enter 1 to move right or 0 to move left: 1                                        
                                                                                                                                                              
Total Head Movements = 394  

2)
Enter number of requests: 7                                                                                             
Enter queue of requests: 78 68 14 53 46 97 182                                                                          
Enter head position: 50                                                                                            
Enter 1 to move right or 0 to move left: 0 
                                                                                                                                                                                                     
Total Head Movements = 395  
*/

#include<stdio.h> 

int main() {
	int n,i,j;
	printf("Enter number of requests: ");
	scanf("%d",&n);
	int q[n];
	printf("Enter queue of requests: ");
	for(i=0;i<n;i++) {
		scanf("%d",&q[i]);
	}
	//Assuming that tracks are from 0-199;
	int head;
	printf("Enter head position: ");
	scanf("%d",&head);
	int direction;	//1 to move right; 0 to move left;
	printf("Enter 1 to move right or 0 to move left: ");
	scanf("%d",&direction);
	int totalHeadMovements=0;
	if(direction==1) {		
		int leftMax=-999;	//Request that is just less than the head.
		i=0;
		while(i<n) {
			if(q[i]>leftMax && q[i]<head) { 
				leftMax=q[i];
			}
			i++;
		}
		totalHeadMovements+=(2*199)-head+leftMax; 
	}
	else {		
		int rightMin=999;	//Request that is just greater than the head.
		i=0;
		while(i<n) {
			if(q[i]<rightMin && q[i]>head) { 
				rightMin=q[i];
			}
			i++;
		}
		totalHeadMovements+=(2*199)+head-rightMin; 
	}
	printf("\nTotal Head Movements = %d\n",totalHeadMovements);
}
