//First Come first Serve -- Disc Scheduling Algorithm

/*
Input:
7
78 63 14 53 46 97 182
50
	
Output:
Enter number of requests: 7                                                                                             
Enter queue of requests: 78 63 14 53 46 97 182                                                                          
Enter head position: 50                                                             
                                    
Total Head Movements = 274                                                                                                        
*/

#include<stdio.h> 

int main() {
	int n,i;
	printf("Enter number of requests: ");
	scanf("%d",&n);
	printf("Enter queue of requests: ");
	int q[n];
	for(i=0;i<n;i++) {
		scanf("%d",&q[i]);
	}
	int head;
	printf("Enter head position: ");
	scanf("%d",&head);
	int totalHeadMovements=0;
	for(i=0;i<n;i++) {
		int cur=(head-q[i]);
		totalHeadMovements+=(cur<0)?(-1*cur):cur;
		head=q[i];
	}
	printf("\nTotal Head Movements = %d\n",totalHeadMovements);
}
