//SCAN -- Disk Scheduling Algorithm

/*
Input/Output:
Enter number of requests: 7                                                                                             
Enter queue of requests: 78 63 14 53 48 97 182                                                                          
Enter head position: 50                                                                                                 
Enter 1 to move right or 0 to move left: 1                  
                                                                                                                                                                                    
Total Head Movements = 334 
*/

#include<stdio.h> 

int main() {
	int n,i,j;
	printf("Enter number of requests: ");
	scanf("%d",&n);
	int q[n];
	printf("Enter queue of requests: ");
	for(i=0;i<n;i++) {
		scanf("%d",&q[i]);
	}
	//Assuming that tracks are from 0-199;
	int head;
	printf("Enter head position: ");
	scanf("%d",&head);
	int direction;	//1 to move right; 0 to move left;
	printf("Enter 1 to move right or 0 to move left: ");
	scanf("%d",&direction);
	int totalHeadMovements=0;
	if(direction==0) {		//Goes to the last leftmost track, and then comes to the right maximum request!
		totalHeadMovements+=(head-0);
		int maxi=head;
		for(i=0;i<n;i++) {
			if(q[i]>maxi) {
				maxi=q[i];
			}
		}
		totalHeadMovements+=(maxi-0);
	}
	else {		//Goes to the last rightmost track, and then comes to the left minimum request!
		totalHeadMovements+=(199-head);
		int mini=head;
		for(i=0;i<n;i++) {
			if(q[i]<mini) {
				mini=q[i];
			}
		}
		totalHeadMovements+=(199-mini);
	}
	printf("\nTotal Head Movements = %d\n",totalHeadMovements);
}
