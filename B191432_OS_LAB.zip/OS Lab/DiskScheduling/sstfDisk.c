//Shortest Seek Time First -- Disc Scheduling Algorithm

/*
Input/Output:
1)
7
78 63 14 53 46 97 182
50

Enter number of requests: 7                                                                                             
Enter queue of requests: 78 63 14 53 46 97 182                                                                          
Enter head position: 50                                                                                                                                                                                                                         

Order of Head track movements: 53       46      63      78      97      14      182                                     
Total Head Movements = 312 

2)
6
83 72 14 147 16 150 
65

Enter number of requests: 6                                                                                             
Enter queue of requests: 83 72 14 147 16 150                                                                            
Enter head position: 65                                                                                                                                                                                                                         
Order of Head track movements: 72       83      147     150     16      14                                              
Total Head Movements = 221                                                                                                          
*/

#include<stdio.h> 

int main() {
	int n,i,j;
	printf("Enter number of requests: ");
	scanf("%d",&n);
	printf("Enter queue of requests: ");
	int q[n];
	for(i=0;i<n;i++) {
		scanf("%d",&q[i]);
	}
	int head;
	printf("Enter head position: ");
	scanf("%d",&head);
	int totalHeadMovements=0;
	printf("\nOrder of Head track movements: ");
	for(i=0;i<n;i++) {
		int mini=999;
		int index=-1;
		for(j=0;j<n;j++) {
			int cur=head-q[j];
			cur=(cur<0)?(-1*cur):cur;
			if(cur<mini) {
				mini=cur;
				index=j;
			}
		}
		printf("%d\t",q[index]); 
		if(index!=-1) {
			int cur=(head-q[index]);
			totalHeadMovements+=(cur<0)?(-1*cur):cur;	
			head=q[index];
			q[index]=999;
		}
	}
	printf("\nTotal Head Movements = %d\n",totalHeadMovements);
}
