//LOOK -- Disk Scheduling Algorithm

/*
Input/Output:
1)
Enter number of requests: 7                                                                                             
Enter queue of requests: 78 63 14 53 46 97 182                                                                          
Enter head position: 50                                                                                                 
Enter 1 to move right or 0 to move left: 1 
                                                                                                                                                                                                     
Total Head Movements = 300 

2)
Enter number of requests: 7                                                                                             
Enter queue of requests: 78 63 14 53 46 97 182                                                                          
Enter head position: 50                                                                                                 
Enter 1 to move right or 0 to move left: 0 
                                                                                                                                                                                                     
Total Head Movements = 204 
*/

#include<stdio.h> 

int main() {
	int n,i,j;
	printf("Enter number of requests: ");
	scanf("%d",&n);
	int q[n];
	printf("Enter queue of requests: ");
	for(i=0;i<n;i++) {
		scanf("%d",&q[i]);
	}
	//Assuming that tracks are from 0-199;
	int head;
	printf("Enter head position: ");
	scanf("%d",&head);
	int direction;	//1 to move right; 0 to move left;
	printf("Enter 1 to move right or 0 to move left: ");
	scanf("%d",&direction);
	int totalHeadMovements=0;
	for(i=0;i<n-1;i++) {
		for(j=0;j<n-i-1;j++) {
			if(q[j]>q[j+1]) {
				int t=q[j];
				q[j]=q[j+1];
				q[j+1]=t;
			}
		}
	}
	if(direction==0) {		//Goes to the left minimum request, and then comes to the right maximum request!
		totalHeadMovements+=(head+q[n-1]-2*q[0]);	//totalHeadMovements+=(head-q[0])+(q[n-1]-q[0]);
	}
	else {		//Goes to the right maximum request, and then comes to the left minimum request!
		totalHeadMovements+=(2*q[n-1]-head-q[0]);	//totalHeadMovements+=(q[n-1]-head)+(q[n-1]-q[0]);
	}
	printf("\nTotal Head Movements = %d\n",totalHeadMovements);
}
