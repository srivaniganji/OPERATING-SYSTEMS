//SCAN -- Disk Scheduling Algorithm

/*
Input/Output:
1)
Enter number of requests: 7                                                                                             
Enter queue of requests: 78 63 14 53 46 97 182                                                                          
Enter head position: 50                                                                                                 
Enter 1 to move right or 0 to move left: 1 
                                                                                                                                                                                                     
Total Head Movements = 332 

2)
Enter number of requests: 7                                                                                             
Enter queue of requests: 78 63 14 53 46 97 182                                                                          
Enter head position: 50                                                                                                 
Enter 1 to move right or 0 to move left: 0 
                                                                                                                                                                                                     
Total Head Movements = 333 
*/

#include<stdio.h> 

int main() {
	int n,i,j;
	printf("Enter number of requests: ");
	scanf("%d",&n);
	int q[n];
	printf("Enter queue of requests: ");
	for(i=0;i<n;i++) {
		scanf("%d",&q[i]);
	}
	//Assuming that tracks are from 0-199;
	int head;
	printf("Enter head position: ");
	scanf("%d",&head);
	int direction;	//1 to move right; 0 to move left;
	printf("Enter 1 to move right or 0 to move left: ");
	scanf("%d",&direction);
	int totalHeadMovements=0;
	for(i=0;i<n-1;i++) {
		for(j=0;j<n-i-1;j++) {
			if(q[j]>q[j+1]) {
				int t=q[j];
				q[j]=q[j+1];
				q[j+1]=t;
			}
		}
	}
	if(direction==0) {		//Goes to the left minimum request, and then comes to the right maximum request, and then again goes to the just right maximum request than head!
		int rightMin=999;
		i=n-1;
		while(i>=0 && q[i]>head) {
			i--;
		}
		rightMin=q[i+1];
		totalHeadMovements+=(head+2*q[n-1]-2*q[0]-rightMin);	
	}
	else {		//Goes to the right maximum request, and then comes to the left minimum request, and then again goes to the just left maximum request than head!
		int leftMax=-999;
		i=0;
		while(i<n && q[i]<head) {
			i++;
		}
		leftMax=q[i-1];
		totalHeadMovements+=(2*q[n-1]-head-2*q[0]+leftMax);	
	}
	printf("\nTotal Head Movements = %d\n",totalHeadMovements);
}
