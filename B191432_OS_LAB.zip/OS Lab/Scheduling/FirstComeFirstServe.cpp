#include<stdio.h> 
struct process {
	int at;
	int bt;
};
void sortArrivalTime(struct process p[],int n) {
	for(int i=0;i<n;i++) {
		for(int j=i+1;j<n;j++) {
			if(p[i].at>p[j].at) {
				struct process temp = p[i];
				p[i]=p[j];
				p[j]=temp;
			}
		}
	}
}
int max(int a,int b)
{
	if(a>b)
	return a;
	else 
	return b;
}
int main() {
	int n;
	printf("Enter number of processes: ");
	scanf("%d",&n);
	struct process p[20];
	printf("Enter arrival time and burst time respectively..:\n");
	for(int i=0;i<n;i++) {
		scanf("%d%d",&p[i].at,&p[i].bt);
	}
	sortArrivalTime(p,n);
	int ct[20],tat[20],wt[20];
	float awt=0,atat=0;
	ct[0]=p[0].at+p[0].bt;
	for(int i=1;i<n;i++) {
		ct[i]=max(p[i].at,ct[i-1])+p[i].bt;
	}
	for(int i=0;i<n;i++) {
		tat[i]=ct[i]-p[i].at;
		wt[i]=tat[i]-p[i].bt;
		awt+=wt[i];
		atat+=tat[i];
	}
	printf("AT \t BT \t CT \t TAT \t WT \n");
	for(int i=0;i<n;i++) {
		printf("%d \t %d \t %d \t %d \t %d \n",p[i].at,p[i].bt,ct[i],tat[i],wt[i]);
	}
	printf("\nAverage Waiting time = %.2f",awt/n);
	printf("\nAverage Turn Around time = %.2f",atat/n);
}
