//Shortest Job First Algorithm

#include<stdio.h>  

void swap(int &a,int &b) {
	int temp = a;
	a = b;
	b = temp;
}

int max(int a,int b) {
	if(a>b)
		return a;
	return b;
}

int main() {
	int n;
	printf("Enter number of processes: ");
	scanf("%d",&n);
	int arrivalTime[n],burstTime[n],process[n];
	printf("Enter arrival time and burst time of each process respectively: \n");
	for(int i=0;i<n;i++) {
		process[i]=i+1;
		scanf("%d%d",&arrivalTime[i],&burstTime[i]);
	}
	for(int i=0;i<n;i++) {
		for(int j=0;j<n-i-1;j++) {
			if(arrivalTime[j]>arrivalTime[j+1]) {
				swap(process[j],process[j+1]);
				swap(arrivalTime[j],arrivalTime[j+1]);
				swap(burstTime[j],burstTime[j+1]);
			}
			else if(arrivalTime[j]==arrivalTime[j+1]) {
				if(burstTime[j]>burstTime[j+1]) {
					swap(process[j],process[j+1]);
					swap(burstTime[j],burstTime[j+1]);
				}
			}
		}
	}
	int completionTime[n],turnAroundTime[n],waitingTime[n]; 
	completionTime[0]=arrivalTime[0]+burstTime[0];
	for(int i=1;i<n;i++) {
		completionTime[i]=max(arrivalTime[i],completionTime[i-1])+burstTime[i];
	}
	float awt=0,atat=0;
	for(int i=0;i<n;i++) {
		turnAroundTime[i]=completionTime[i]-arrivalTime[i];
		waitingTime[i]=turnAroundTime[i]-burstTime[i];
		atat+=turnAroundTime[i];
		awt+=waitingTime[i];
	}
	printf("Process\tArrivalTime\tBurstTime\tCompletionTime\tTurnAroundTime\tWaitingTime\n");
	for(int i=0;i<n;i++) {
		printf("%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t\n",process[i],arrivalTime[i],burstTime[i],completionTime[i],turnAroundTime[i],waitingTime[i]);
	}
	printf("Average turn around time = %.2f\n",atat/n);
	printf("Average waiting time = %.2f\n",awt/n);
}
