//LRU

/*
Input:
20 
4
7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1

Output: 
Enter number of pages: 20                                                                                               
Enter number of frames: 4                                                                                               
Enter each page: 7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1                                                                
Page Faults = 8   
*/

#include<stdio.h>

int main() {
	int nPages;
	printf("Enter number of pages: ");
	scanf("%d",&nPages);
	int nFrames;
	printf("Enter number of frames: ");
	scanf("%d",&nFrames);
	int pages[nPages],flag[nPages];
	printf("Enter each page: ");
	for(int i=0;i<nPages;i++) {
		scanf("%d",&pages[i]);
		flag[i]=0;
	}
	int count[nFrames],frame[nFrames],pageFaults=0;
	for(int i=0;i<nFrames;i++) {
		count[i]=0;
		frame[i]=-1;
	}
	int next=0,mini;
	for(int i=0;i<nPages;i++) {
		for(int j=0;j<nFrames;j++) {
			if(frame[j]==pages[i]) {
				flag[i]=1;
				count[j]=next;
				next++;
			}
		}
		if(flag[i]==0) {
			if(i<nFrames) {
				frame[i]=pages[i]; 
				count[i]=next;
				next++;
			}
			else {
				mini=0;
				for(int j=1;j<nFrames;j++) {
					if(count[mini]>count[j]) {
						mini=j;
					}
				}
				frame[mini]=pages[i];
				count[mini]=next;
				next++;
			}
			pageFaults++;
		}
	}
	printf("Page Faults = %d\n",pageFaults);
}
