//First In First Out

/*
Input:
20 
3
7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1

Output:
Page Faults = 15
*/

#include<stdio.h> 

int FirstInFirstOut(int nPages,int pages[],int nFrames) {
	int pageFaults=0,frames[nFrames];
	for(int i=0;i<nFrames;i++) {
		frames[i]=-1;
	}
	int current=0;
	for(int i=0;i<nPages;i++) {
		int isFound=0;
		for(int j=0;j<nFrames;j++) {
			if(pages[i]==frames[j]) {
				isFound=1;
				break;
			}
		}
		if(isFound==0) {
			frames[current]=pages[i];
			current=(current+1)%nFrames;
			pageFaults++;
		}
	}
	return pageFaults;
}

int main() {
	int nPages;
	printf("Enter number of pages: ");
	scanf("%d",&nPages); 
	int nFrames;
	printf("Enter number of frames: ");
	scanf("%d",&nFrames);
	int pages[nPages];
	printf("Enter sizes of each page: ");
	for(int i=0;i<nPages;i++) {
		scanf("%d",&pages[i]);
	}
	int pageFaults=FirstInFirstOut(nPages,pages,nFrames);
	printf("Page Faults = %d\n",pageFaults);
}
