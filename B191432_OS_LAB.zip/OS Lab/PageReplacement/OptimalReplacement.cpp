//Optimal Page Replacement algorihtm

/*
Input:
20 
4
7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1

Output: 
Enter number of pages: 20                                                                                               
Enter number of frames: 4                                                                                               
Enter each page: 7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1     
Number of Hits: 12                                                           
Number of Page Faults = 8   
*/

#include<iostream> 
#include<vector>

int searchPageInFrames(int page,std::vector<int>&frames) {
	for(int i=0;i<frames.size();i++) {
		if(frames[i]==page)
			return 1;
	}
	return 0;
}

int predictFrame(int nPages,int pages[],std::vector<int>&frames,int index) {
	int result=-1,farthest=index;
	for(int i=0;i<frames.size();i++) {
		int j;
		for(j=index;j<nPages;j++) {
			if(frames[i]==pages[j]) {
				if(j>farthest) {
					farthest=j;
					result=i;
				}
				break;
			}
		} 
		if(j==nPages) 
			return i;
	}
    //return (result==-1) ? 0 : result;
    return result;
}

int main() {
	int nPages;
	printf("Enter number of pages: ");
	scanf("%d",&nPages);
	int nFrames;
	printf("Enter number of Frames: ");
	scanf("%d",&nFrames);
	int pages[nPages];
	printf("Enter each page size: ");
	for(int i=0;i<nPages;i++) {
		scanf("%d",&pages[i]);
	}
	std::vector<int>frames;
	int hits=0,pageFaults=0;
	for(int i=0;i<nPages;i++) {
		if(searchPageInFrames(pages[i],frames)) {
			hits++;
			continue;
		}
		if(frames.size()<nFrames)
			frames.push_back(pages[i]);
		else {
			int j=predictFrame(nPages,pages,frames,i+1);
			frames[j]=pages[i];
		}
	}
	pageFaults=nPages-hits;
	printf("Number of Hits = %d\n",hits);
	printf("Number of Page Faults = %d\n",pageFaults);
}
