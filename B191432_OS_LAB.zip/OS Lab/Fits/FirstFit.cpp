//First Fit 


/*
Input:
5
20 40 70 10 15
4
30 20 90 70

Output:
Enter number of processes: 5                                                                                            
Enter processes: 20 40 70 10 15                                                                                         
Enter number of blocks: 4                                                                                               
Enter blocks: 30 20 90 70        
                                                                                       
Process Number  Process size    Block Allocated                                                                         
1               20              1                                                                                       
2               40              3                                                                                       
3               70              4                                                                                       
4               10              2                                                                                       
5               15              Not Allocated                                                                           
Internal fragmentation = 70                                                                                             
External fragmentation = 70
*/


#include<stdio.h> 

void firstFit(int n,int blockNo,int process[],int block[]) {
	int visited[blockNo],blockAllocated[n];
	for(int i=0;i<blockNo;i++) {
		visited[i]=0;
	}
	for(int i=0;i<n;i++) {
		blockAllocated[i]=-1;
	}
	for(int i=0;i<n;i++) {
		for(int j=0;j<blockNo;j++) {
			if(visited[j]!=1 && block[j]>=process[i]) {
				visited[j]=1;
				blockAllocated[i]=j;
				block[j]-=process[i];
				break;
			}
		}
	}
	printf("\nProcess Number\tProcess size\tBlock Allocated\n");
	for(int i=0;i<n;i++) {
		printf("%d\t\t%d\t\t",i+1,process[i]);
		if(blockAllocated[i]!=-1)
			printf("%d\n",blockAllocated[i]+1);
		else 
			printf("Not Allocated\n");
	}
	int internalFragmentation=0,externalFragmentation;
	for(int i=0;i<blockNo;i++) {
		if(visited[i]==1) {
			internalFragmentation+=(block[i]);
		}
	}
	externalFragmentation=internalFragmentation;
	for(int i=0;i<blockNo;i++) {
		if(visited[i]!=1) {
			externalFragmentation+=(block[i]);
		}
	}
	printf("Internal fragmentation = %d\n",internalFragmentation);
	printf("External fragmentation = %d\n",externalFragmentation);
}

int main() {
	int n,blockNo;
	printf("Enter number of processes: ");
	scanf("%d",&n);
	int process[n];
	printf("Enter processes: ");
	for(int i=0;i<n;i++) {
		scanf("%d",&process[i]);
	}
	printf("Enter number of blocks: ");
	scanf("%d",&blockNo);
	int block[blockNo];
	printf("Enter blocks: "); 
	for(int i=0;i<blockNo;i++) {
		scanf("%d",&block[i]);
	}
	firstFit(n,blockNo,process,block);
}
