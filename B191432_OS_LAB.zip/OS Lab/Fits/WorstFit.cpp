//Worst Fit 

/*
Input:
5
20 40 70 10 15
4
30 20 90 70

Output:
Enter number of processes: 5                                                                                            
Enter processes: 20 40 70 10 15                                                                                         
Enter number of blocks: 4                                                                                               
Enter blocks: 30 20 90 70        
                                                                                       
Process Number  Process size    Block Allocated                                                                         
1               20              3                                                                                       
2               40              4                                                                                       
3               70              Not Allocated                                                                                      
4               10              1                                                                                       
5               15              2                                                                           
Internal fragmentation = 125                                                                                             
External fragmentation = 125
*/

#include<stdio.h> 

void worstFit(int n,int blockNo,int process[],int block[]) {
	int visited[blockNo],blockAllocated[n];
	for(int i=0;i<blockNo;i++) {
		visited[i]=0;
	}
	for(int i=0;i<n;i++) {
		blockAllocated[i]=-1;
	}
	for(int i=0;i<n;i++) {
		int maxi=-1;
		for(int j=0;j<blockNo;j++) {
			if(block[j]>=process[i] && visited[j]!=1) {
				if(maxi==-1) {
					maxi=j;
				}
				else if(block[j]>block[maxi]) {
					maxi=j;
				}
			}
		}
		if(maxi!=-1) {
			visited[maxi]=1;
			blockAllocated[i]=maxi;
			block[maxi]-=process[i];
		}
	}
	printf("\nProcess Number\tProcess size\tBlock Allocated\n");
	for(int i=0;i<n;i++) {
		printf("%d\t\t%d\t\t",i+1,process[i]);
		if(blockAllocated[i]!=-1)
			printf("%d\n",blockAllocated[i]+1);
		else 
			printf("Not Allocated\n");
	}
	int internalFragmentation=0,externalFragmentation;
	for(int i=0;i<blockNo;i++) {
		if(visited[i]==1) {
			internalFragmentation+=(block[i]);
		}
	}
	externalFragmentation=internalFragmentation;
	for(int i=0;i<blockNo;i++) {
		if(visited[i]!=1) {
			externalFragmentation+=(block[i]);
		}
	}
	printf("Internal fragmentation = %d\n",internalFragmentation);
	printf("External fragmentation = %d\n",externalFragmentation);
}

int main() {
	int n,blockNo;
	printf("Enter number of processes: ");
	scanf("%d",&n);
	int process[n];
	printf("Enter processes: ");
	for(int i=0;i<n;i++) {
		scanf("%d",&process[i]);
	}
	printf("Enter number of blocks: ");
	scanf("%d",&blockNo);
	int block[blockNo];
	printf("Enter blocks: "); 
	for(int i=0;i<blockNo;i++) {
		scanf("%d",&block[i]);
	}
	worstFit(n,blockNo,process,block);
}
